import React from 'react';

const Header = () => (
  <header className="bg-danger text-white text-center py-3">
    <h1>BOM PRA BARALHO</h1>
  </header>
);

export default Header;
